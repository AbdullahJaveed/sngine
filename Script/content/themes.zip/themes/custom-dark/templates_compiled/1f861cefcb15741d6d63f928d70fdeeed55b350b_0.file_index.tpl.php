<?php
/* Smarty version 5.5.2, created on 2025-10-14 06:43:34
  from 'file:index.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68edf11641b8c3_08616470',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1f861cefcb15741d6d63f928d70fdeeed55b350b' => 
    array (
      0 => 'index.tpl',
      1 => 1760376573,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68edf11641b8c3_08616470 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/custom-dark/templates';
?><!DOCTYPE html>
<html>
<head>
  <title>Custom Dark Test</title>
  <style>
    body {
      background-color: red;
      color: white;
      font-family: Arial, sans-serif;
    }
  </style>
</head>
<body>
  <h1>Custom Dark Theme Loaded Successfully 🎨</h1>
</body>
</html>
<?php }
}
