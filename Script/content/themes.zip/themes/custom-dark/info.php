<?php
/**
 * Custom Dark Theme
 *
 * @package Sngine
 * @author Pixel Perfects
 */

return [
  'name'        => 'Custom Dark',
  'version'     => '1.0.0',
  'author'      => 'Pixel Perfects',
  'description' => 'A modern dark UI for Sngine with high readability and responsive design.',
  'website'     => 'https://pxlperfects.com',
  'color'       => '#121212', // used for admin color swatch
];
