<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:48:58
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/reels.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f6a0c64b2_97158506',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '90d5410732dd86c0b64b840ed0e51faa27692df4' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/reels.svg',
      1 => 1760349426,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed1f6a0c64b2_97158506 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
echo '<?'; ?>
xml version="1.0" standalone="no"<?php echo '?>'; ?>

<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 20010904//EN"
 "http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd">
<svg version="1.0" xmlns="http://www.w3.org/2000/svg"
 width="512.000000pt" height="512.000000pt" viewBox="0 0 512.000000 512.000000"
 preserveAspectRatio="xMidYMid meet">

<g transform="translate(0.000000,512.000000) scale(0.100000,-0.100000)"
fill="#000000" stroke="none">
<path d="M761 5099 c-356 -75 -636 -342 -733 -699 l-23 -85 0 -1750 0 -1750
23 -90 c30 -119 106 -271 183 -368 121 -152 317 -278 509 -329 l85 -23 1700
-3 c1269 -2 1723 0 1790 9 313 41 585 237 725 524 27 55 60 141 72 190 l23 90
0 1745 0 1745 -23 90 c-78 311 -321 574 -622 675 -153 51 -101 50 -1920 49
-1650 0 -1697 -1 -1789 -20z m817 -779 c183 -247 332 -452 332 -455 0 -3 -351
-5 -780 -5 l-780 0 0 163 c0 171 10 258 39 343 54 161 199 306 364 364 86 30
147 38 328 39 l165 1 332 -450z m1499 20 c173 -234 323 -437 334 -452 l20 -28
-538 0 -538 1 -325 441 c-179 242 -329 447 -333 455 -7 11 78 13 529 11 l537
-3 314 -425z m1196 415 c223 -39 409 -209 472 -431 12 -43 19 -115 22 -262 l5
-202 -452 2 -453 3 -329 445 c-180 244 -328 448 -328 452 0 5 222 8 493 8 374
-1 511 -4 570 -15z m492 -2565 c0 -1425 2 -1359 -55 -1485 -59 -129 -164 -234
-297 -297 -128 -60 -70 -59 -1894 -55 -1497 2 -1669 4 -1716 19 -217 67 -366
215 -429 424 -17 55 -19 142 -21 1374 -2 723 -1 1320 1 1327 4 11 418 13 2208
11 l2203 -3 0 -1315z"/>
<path d="M1930 2889 c-20 -11 -47 -37 -60 -56 l-25 -37 -3 -854 c-2 -852 -2
-855 19 -899 31 -64 91 -97 167 -91 54 4 97 28 772 418 393 227 723 420 734
429 30 26 56 87 56 131 0 50 -30 112 -67 138 -33 23 -1358 789 -1420 821 -55
27 -126 28 -173 0z m723 -723 c218 -127 397 -233 397 -236 0 -5 -779 -459
-852 -497 -5 -2 -8 221 -8 497 l0 500 33 -17 c19 -10 212 -121 430 -247z"/>
</g>
</svg>
<?php }
}
