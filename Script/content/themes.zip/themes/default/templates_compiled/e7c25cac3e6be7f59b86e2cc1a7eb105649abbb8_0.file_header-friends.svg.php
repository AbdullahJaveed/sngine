<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:48:54
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/header-friends.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f6665c715_16026884',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e7c25cac3e6be7f59b86e2cc1a7eb105649abbb8' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/header-friends.svg',
      1 => 1760349426,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed1f6665c715_16026884 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
?><svg id="Icons" enable-background="new 0 0 128 128" height="512" viewBox="0 0 128 128" width="512" xmlns="http://www.w3.org/2000/svg"><path id="Add_User" d="m96 64c-5.898 0-11.41 1.632-16.159 4.427l-5.325-2.13c-1.53-.609-2.516-2.07-2.516-3.715v-3.102l.248-.055c6.92-1.898 11.752-8.241 11.752-15.425v-16c0-15.437-12.561-28-28-28s-28 12.563-28 28v16c0 7.184 4.832 13.527 12 15.48v3.102c0 1.645-.986 3.105-2.516 3.715l-24.91 9.965c-7.638 3.054-12.574 10.343-12.574 18.57v13.168c0 4.41 3.588 8 8 8h63.06c5.87 7.305 14.862 12 24.94 12 17.645 0 32-14.355 32-32s-14.355-32-32-32zm-88 44v-13.168c0-4.938 2.961-9.309 7.545-11.141l24.912-9.965c4.582-1.835 7.543-6.206 7.543-11.144v-3.102c0-3.633-2.461-6.754-6.131-7.766-3.455-.948-5.869-4.12-5.869-7.714v-16c0-11.027 8.973-20 20-20s20 8.973 20 20v16c0 3.594-2.414 6.766-5.875 7.715-3.664 1.012-6.125 4.133-6.125 7.765v3.102c0 4.938 2.961 9.309 7.543 11.145l1.121.448c-5.356 5.723-8.664 13.387-8.664 21.825 0 4.245.849 8.29 2.356 12zm88 12c-13.234 0-24-10.766-24-24s10.766-24 24-24 24 10.766 24 24-10.766 24-24 24zm16-24c0 2.211-1.791 4-4 4h-8v8c0 2.211-1.791 4-4 4s-4-1.789-4-4v-8h-8c-2.209 0-4-1.789-4-4s1.791-4 4-4h8v-8c0-2.211 1.791-4 4-4s4 1.789 4 4v8h8c2.209 0 4 1.789 4 4z"/></svg><?php }
}
