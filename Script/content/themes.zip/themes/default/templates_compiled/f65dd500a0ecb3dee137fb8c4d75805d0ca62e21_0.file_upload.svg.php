<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:49:00
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/upload.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f6c494947_23153403',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f65dd500a0ecb3dee137fb8c4d75805d0ca62e21' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/upload.svg',
      1 => 1760349433,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed1f6c494947_23153403 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
?><svg id="Layer_3" height="512" viewBox="0 0 32 32" width="512" xmlns="http://www.w3.org/2000/svg" data-name="Layer 3"><path d="m23.75 11.044a7.99 7.99 0 0 0 -15.5-.009 8 8 0 0 0 .75 15.965h3a1 1 0 0 0 0-2h-3a6 6 0 0 1 -.035-12 1.038 1.038 0 0 0 1.1-.854 5.991 5.991 0 0 1 11.862 0 1.08 1.08 0 0 0 1.073.854 6 6 0 0 1 0 12h-3a1 1 0 0 0 0 2h3a8 8 0 0 0 .75-15.956z"/><path d="m20.293 19.707a1 1 0 0 0 1.414-1.414l-5-5a1 1 0 0 0 -1.414 0l-5 5a1 1 0 0 0 1.414 1.414l3.293-3.293v12.586a1 1 0 0 0 2 0v-12.586z"/></svg><?php }
}
