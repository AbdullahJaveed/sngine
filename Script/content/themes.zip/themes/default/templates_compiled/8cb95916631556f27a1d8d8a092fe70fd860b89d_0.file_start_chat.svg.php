<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:49:03
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/start_chat.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f6f647350_53313020',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8cb95916631556f27a1d8d8a092fe70fd860b89d' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/start_chat.svg',
      1 => 1760349427,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed1f6f647350_53313020 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path fill="#5e72e4" fill-rule="evenodd" d="M4 1a3 3 0 0 0-3 3v11a3 3 0 0 0 3 3v2.586a2.414 2.414 0 0 0 4.121 1.707l4.586-4.586a1 1 0 0 0-1.414-1.414l-4.586 4.586A.414.414 0 0 1 6 20.586V17a1 1 0 0 0-1-1H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h16a1 1 0 0 1 1 1v6a1 1 0 1 0 2 0V4a3 3 0 0 0-3-3zm15 12a1 1 0 0 1 1 1v2h2a1 1 0 1 1 0 2h-2v2a1 1 0 0 1-2 0v-2h-2a1 1 0 1 1 0-2h2v-2a1 1 0 0 1 1-1z" clip-rule="evenodd" data-original="#000000" class=""></path></g></svg><?php }
}
