<?php
/* Smarty version 5.5.2, created on 2025-10-13 17:21:15
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/user_add.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed350bcaa8f2_76713806',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4e5d4f7cb7a5a0b3802451448067d9683936435b' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/user_add.svg',
      1 => 1760349425,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed350bcaa8f2_76713806 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 32 32" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M28 22.5h-3.5V19a1 1 0 0 0-2 0v3.5H19a1 1 0 0 0 0 2h3.5V28a1 1 0 0 0 2 0v-3.5H28a1 1 0 0 0 0-2z" fill="#5e72e4" data-original="#000000" class=""></path><path d="M16 29H6a1 1 0 0 1-1-1 11.013 11.013 0 0 1 11-11 8.025 8.025 0 1 0-4.289-1.258A13.012 13.012 0 0 0 3 28a3 3 0 0 0 3 3h10a1 1 0 0 0 0-2zM10 9a6 6 0 1 1 6 6 6.006 6.006 0 0 1-6-6z" fill="#5e72e4" data-original="#000000" class=""></path></g></svg><?php }
}
