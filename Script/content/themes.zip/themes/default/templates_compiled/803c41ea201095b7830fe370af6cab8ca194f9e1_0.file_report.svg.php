<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:48:36
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/report.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f5451ecc2_80908344',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '803c41ea201095b7830fe370af6cab8ca194f9e1' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/report.svg',
      1 => 1760349429,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed1f5451ecc2_80908344 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="m357.14 181.14-73.355 73.36 73.356 73.36c7.812 7.808 7.812 20.472 0 28.28-3.903 3.907-9.024 5.86-14.141 5.86s-10.238-1.953-14.14-5.86l-73.36-73.355-73.36 73.356C178.239 360.047 173.118 362 168 362s-10.238-1.953-14.14-5.86c-7.813-7.808-7.813-20.472 0-28.28l73.355-73.36-73.356-73.36c-7.812-7.808-7.812-20.472 0-28.28 7.809-7.813 20.473-7.813 28.282 0l73.359 73.355 73.36-73.356c7.808-7.812 20.472-7.812 28.28 0 7.813 7.809 7.813 20.473 0 28.282zm79.88-106.16C388.668 26.63 324.379 0 256 0S123.332 26.629 74.98 74.98C26.63 123.332 0 187.621 0 256s26.629 132.668 74.98 181.02C123.332 485.37 187.621 512 256 512c46.813 0 92.617-12.758 132.46-36.895 9.45-5.722 12.47-18.02 6.747-27.464-5.723-9.45-18.023-12.47-27.469-6.746C334.145 461.242 295.504 472 256 472c-119.102 0-216-96.898-216-216S136.898 40 256 40s216 96.898 216 216c0 42.59-12.664 84.043-36.625 119.887-6.14 9.18-3.672 21.601 5.512 27.742 9.18 6.137 21.601 3.672 27.742-5.512C497 355.676 512 306.531 512 256c0-68.379-26.629-132.668-74.98-181.02zm0 0" fill="#5e72e4" data-original="#000000" class=""></path></g></svg><?php }
}
