<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:49:04
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/payments.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f7015fc42_79265920',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5dafa4614cae0e865d79168f66ff0063088f4200' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/payments.svg',
      1 => 1760349432,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed1f7015fc42_79265920 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 32 32" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M27 27H5a3 3 0 0 1-3-3V8a3 3 0 0 1 3-3h22a3 3 0 0 1 3 3v16a3 3 0 0 1-3 3zM4 15v9a1 1 0 0 0 1 1h22a1 1 0 0 0 1-1v-9zm0-2h24v-2H4zm0-4h24V8a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1zm21 14h-1a1 1 0 0 1 0-2h1a1 1 0 0 1 0 2zm-4 0h-1a1 1 0 0 1 0-2h1a1 1 0 0 1 0 2zm-8 0H7a1 1 0 0 1 0-2h6a1 1 0 0 1 0 2z" fill="#5e72e4" data-original="#000000" class=""></path></g></svg><?php }
}
