<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:48:53
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/blogs.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f65e1f976_91603488',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1fd837b109c04f931753a3f0fec7dd3a3ebb473a' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/blogs.svg',
      1 => 1760349429,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed1f65e1f976_91603488 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M21.75 5v14A3.75 3.75 0 0 1 18 22.75H6A3.75 3.75 0 0 1 2.25 19V5A3.75 3.75 0 0 1 6 1.25h12A3.75 3.75 0 0 1 21.75 5zm-1.5 0A2.25 2.25 0 0 0 18 2.75H6A2.25 2.25 0 0 0 3.75 5v14A2.25 2.25 0 0 0 6 21.25h12A2.25 2.25 0 0 0 20.25 19z" fill="#5e72e4" data-original="#000000" class=""></path><path d="M12 5.25a.75.75 0 0 1 0 1.5H7a.75.75 0 0 1 0-1.5zM17 9.25a.75.75 0 0 1 0 1.5H7a.75.75 0 0 1 0-1.5zM17 13.25a.75.75 0 0 1 0 1.5H7a.75.75 0 0 1 0-1.5zM17 17.25a.75.75 0 0 1 0 1.5H7a.75.75 0 0 1 0-1.5z" fill="#5e72e4" data-original="#000000" class=""></path></g></svg><?php }
}
