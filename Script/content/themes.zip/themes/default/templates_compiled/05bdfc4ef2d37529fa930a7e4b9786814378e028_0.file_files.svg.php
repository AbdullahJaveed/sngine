<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:49:01
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/files.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f6d0d31c5_94416439',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '05bdfc4ef2d37529fa930a7e4b9786814378e028' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/files.svg',
      1 => 1760349426,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed1f6d0d31c5_94416439 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
?><svg height="512" viewBox="0 0 32 32" width="512" xmlns="http://www.w3.org/2000/svg"><g id="Layer_2" data-name="Layer 2"><path d="m26.4 31h-16.63a2.69 2.69 0 0 1 -2.69-2.69v-24.62a2.69 2.69 0 0 1 2.69-2.69h7.63a2.78 2.78 0 0 1 1.85.71l8.9 8a2.79 2.79 0 0 1 .93 2.08v16.52a2.69 2.69 0 0 1 -2.68 2.69zm-16.63-28a.69.69 0 0 0 -.69.69v24.62a.69.69 0 0 0 .69.69h16.63a.69.69 0 0 0 .69-.69v-16.57a.78.78 0 0 0 -.26-.58l-8.9-8a.78.78 0 0 0 -.53-.16z"/><path d="m28.08 11.94h-8.81a2.19 2.19 0 0 1 -2.19-2.19v-7.19h2v7.19a.19.19 0 0 0 .19.19h8.81z"/><rect height="2" rx="1" width="10" x="13.42" y="24"/><rect height="2" rx="1" width="4" x="13.42" y="19.69"/><path d="m5.41 26.66a2.52 2.52 0 0 1 -2.49-2.51v-16.3a2.5 2.5 0 0 1 3-2.45l2.15.36-.33 2-2.17-.39a.53.53 0 0 0 -.46.09.5.5 0 0 0 -.19.39v16.3a.51.51 0 0 0 .61.49l2.26-.3.26 2-2.19.29a2.11 2.11 0 0 1 -.45.03z"/></g></svg><?php }
}
