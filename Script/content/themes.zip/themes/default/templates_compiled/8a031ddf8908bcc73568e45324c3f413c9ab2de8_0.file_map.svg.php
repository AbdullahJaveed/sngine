<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:49:00
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/map.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f6c39b828_98834627',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8a031ddf8908bcc73568e45324c3f413c9ab2de8' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/map.svg',
      1 => 1760349426,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed1f6c39b828_98834627 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path fill="#549bff" d="M12 13.75c-2.068 0-3.75-1.682-3.75-3.75S9.932 6.25 12 6.25s3.75 1.682 3.75 3.75-1.682 3.75-3.75 3.75zm0-6c-1.241 0-2.25 1.009-2.25 2.25s1.009 2.25 2.25 2.25 2.25-1.009 2.25-2.25S13.241 7.75 12 7.75z" data-original="#549bff" class=""></path><path fill="#5e72e4" d="M12 21.75c-2.552 0-7.75-5.439-7.75-11.75 0-4.273 3.477-7.75 7.75-7.75s7.75 3.477 7.75 7.75c0 6.311-5.198 11.75-7.75 11.75zm0-18A6.257 6.257 0 0 0 5.75 10c0 5.638 4.719 10.25 6.25 10.25s6.25-4.612 6.25-10.25A6.257 6.257 0 0 0 12 3.75z" data-original="#112d55" class=""></path></g></svg><?php }
}
