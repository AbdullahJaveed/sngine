<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:48:31
  from 'file:__svg_icons.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f4fcd8c99_32375878',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0d8ae2a67add6b4d63ff100e6d7f4558a4ba1bc7' => 
    array (
      0 => '__svg_icons.tpl',
      1 => 1760349443,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../images/svg/2co.svg' => 1,
    'file:../images/svg/paypal.svg' => 1,
    'file:../images/svg/alipay.svg' => 1,
    'file:../images/svg/bank.svg' => 1,
    'file:../images/svg/bitcoin.svg' => 1,
    'file:../images/svg/photos.svg' => 1,
    'file:../images/svg/videos.svg' => 1,
    'file:../images/svg/audios.svg' => 1,
    'file:../images/svg/files.svg' => 1,
    'file:../images/svg/sun.svg' => 1,
    'file:../images/svg/night.svg' => 1,
    'file:../images/svg/sunrise.svg' => 1,
    'file:../images/svg/scroll_desktop.svg' => 1,
    'file:../images/svg/scroll_mobile.svg' => 1,
    'file:../images/svg/chat.svg' => 1,
    'file:../images/svg/settings.svg' => 1,
    'file:../images/svg/24_hours.svg' => 1,
    'file:../images/svg/trending.svg' => 1,
    'file:../images/svg/memories.svg' => 1,
    'file:../images/svg/language.svg' => 1,
    'file:../images/svg/posts_discover.svg' => 1,
    'file:../images/svg/popularity.svg' => 1,
    'file:../images/svg/posts_colored.svg' => 1,
    'file:../images/svg/posts_recent.svg' => 1,
    'file:../images/svg/social_share.svg' => 1,
    'file:../images/svg/youtube_player.svg' => 1,
    'file:../images/svg/adult.svg' => 1,
    'file:../images/svg/watermark.svg' => 1,
    'file:../images/svg/jobs.svg' => 1,
    'file:../images/svg/google_recaptcha.svg' => 1,
    'file:../images/svg/censored.svg' => 1,
    'file:../images/svg/fingerprint.svg' => 1,
    'file:../images/svg/firewall.svg' => 1,
    'file:../images/svg/chat_status.svg' => 1,
    'file:../images/svg/chat_seen.svg' => 1,
    'file:../images/svg/chat_typing.svg' => 1,
    'file:../images/svg/call_video.svg' => 1,
    'file:../images/svg/call_audio.svg' => 1,
    'file:../images/svg/aws_s3.svg' => 1,
    'file:../images/svg/digitalocean.svg' => 1,
    'file:../images/svg/server.svg' => 1,
    'file:../images/svg/twilio.svg' => 1,
    'file:../images/svg/infobip.svg' => 1,
    'file:../images/svg/bulksms.svg' => 1,
    'file:../images/svg/msg91.svg' => 1,
    'file:../images/svg/email.svg' => 1,
    'file:../images/svg/authentication.svg' => 1,
    'file:../images/svg/ssl.svg' => 1,
    'file:../images/svg/smile.svg' => 1,
    'file:../images/svg/map.svg' => 1,
    'file:../images/svg/polls.svg' => 1,
    'file:../images/svg/gif.svg' => 1,
    'file:../images/svg/wall_posts.svg' => 1,
    'file:../images/svg/verification.svg' => 1,
    'file:../images/svg/age_limit.svg' => 1,
    'file:../images/svg/getting_started.svg' => 1,
    'file:../images/svg/account_activation.svg' => 1,
    'file:../images/svg/newsletter.svg' => 1,
    'file:../images/svg/delete_user.svg' => 2,
    'file:../images/svg/registration.svg' => 1,
    'file:../images/svg/invitation.svg' => 1,
    'file:../images/svg/invite_friend.svg' => 1,
    'file:../images/svg/wallet.svg' => 1,
    'file:../images/svg/resolution.svg' => 1,
    'file:../images/svg/website_live.svg' => 1,
    'file:../images/svg/website_public.svg' => 1,
    'file:../images/svg/directory.svg' => 1,
    'file:../images/svg/contat_us.svg' => 1,
    'file:../images/svg/adblock.svg' => 1,
    'file:../images/svg/cookie.svg' => 1,
    'file:../images/svg/browser_notifications.svg' => 1,
    'file:../images/svg/noty_notifications.svg' => 1,
    'file:../images/svg/profile_notifications.svg' => 1,
    'file:../images/svg/gifts.svg' => 1,
    'file:../images/svg/poke.svg' => 1,
    'file:../images/svg/onesignal.svg' => 1,
    'file:../images/svg/like.svg' => 1,
    'file:../images/svg/comment.svg' => 1,
    'file:../images/svg/share.svg' => 1,
    'file:../images/svg/developers.svg' => 1,
    'file:../images/svg/affiliates.svg' => 1,
    'file:../images/svg/withdrawal.svg' => 1,
    'file:../images/svg/wallet_transfer.svg' => 1,
    'file:../images/svg/pages.svg' => 1,
    'file:../images/svg/groups.svg' => 1,
    'file:../images/svg/events.svg' => 1,
    'file:../images/svg/market.svg' => 1,
    'file:../images/svg/products.svg' => 1,
    'file:../images/svg/forums.svg' => 1,
    'file:../images/svg/ads.svg' => 1,
    'file:../images/svg/movies.svg' => 1,
    'file:../images/svg/games.svg' => 1,
    'file:../images/svg/find_people.svg' => 1,
    'file:../images/svg/saved.svg' => 1,
    'file:../images/svg/blogs.svg' => 1,
    'file:../images/svg/boosted.svg' => 1,
    'file:../images/svg/newsfeed.svg' => 1,
    'file:../images/svg/share_plugin.svg' => 1,
    'file:../images/svg/followings.svg' => 1,
    'file:../images/svg/friends.svg' => 1,
    'file:../images/svg/followers.svg' => 1,
    'file:../images/svg/cloud_save.svg' => 1,
    'file:../images/svg/database.svg' => 1,
    'file:../images/svg/star.svg' => 1,
    'file:../images/svg/profile.svg' => 1,
    'file:../images/svg/chat_bell.svg' => 1,
    'file:../images/svg/notification_bell.svg' => 1,
    'file:../images/svg/user_online.svg' => 1,
    'file:../images/svg/spy.svg' => 1,
    'file:../images/svg/stats.svg' => 1,
    'file:../images/svg/voice_notes.svg' => 1,
    'file:../images/svg/offers.svg' => 1,
    'file:../images/svg/live.svg' => 1,
    'file:../images/svg/delete.svg' => 1,
    'file:../images/svg/empty.svg' => 1,
    'file:../images/svg/ready.svg' => 1,
    'file:../images/svg/relationship.svg' => 1,
    'file:../images/svg/website.svg' => 1,
    'file:../images/svg/biography.svg' => 1,
    'file:../images/svg/education.svg' => 1,
    'file:../images/svg/username.svg' => 1,
    'file:../images/svg/design.svg' => 1,
    'file:../images/svg/funding.svg' => 1,
    'file:../images/svg/money-bag.svg' => 1,
    'file:../images/svg/transaction.svg' => 1,
    'file:../images/svg/paystack.svg' => 1,
    'file:../images/svg/header-menu.svg' => 1,
    'file:../images/svg/header-home.svg' => 1,
    'file:../images/svg/header-plus.svg' => 1,
    'file:../images/svg/header-friends.svg' => 1,
    'file:../images/svg/header-messages.svg' => 1,
    'file:../images/svg/header-notifications.svg' => 1,
    'file:../images/svg/header-search.svg' => 1,
    'file:../images/svg/playstore.svg' => 1,
    'file:../images/svg/playstore_badge.svg' => 1,
    'file:../images/svg/appstore.svg' => 1,
    'file:../images/svg/appstore_badge.svg' => 1,
    'file:../images/svg/appgallery.svg' => 1,
    'file:../images/svg/appgallery_badge.svg' => 1,
    'file:../images/svg/wasabi.svg' => 1,
    'file:../images/svg/google_cloud.svg' => 1,
    'file:../images/svg/html.svg' => 1,
    'file:../images/svg/razorpay.svg' => 1,
    'file:../images/svg/cashfree.svg' => 1,
    'file:../images/svg/coinbase.svg' => 1,
    'file:../images/svg/shift4.svg' => 1,
    'file:../images/svg/stripe.svg' => 1,
    'file:../images/svg/special_characters.svg' => 1,
    'file:../images/svg/backblaze.svg' => 1,
    'file:../images/svg/ffmpeg.svg' => 1,
    'file:../images/svg/reserved.svg' => 1,
    'file:../images/svg/views.svg' => 1,
    'file:../images/svg/locked.svg' => 1,
    'file:../images/svg/noads.svg' => 1,
    'file:../images/svg/moneypoolscash.svg' => 1,
    'file:../images/svg/tips.svg' => 1,
    'file:../images/svg/tip.svg' => 1,
    'file:../images/svg/edit_profile.svg' => 1,
    'file:../images/svg/security.svg' => 1,
    'file:../images/svg/notifications.svg' => 1,
    'file:../images/svg/privacy.svg' => 1,
    'file:../images/svg/blocking.svg' => 1,
    'file:../images/svg/user_add.svg' => 1,
    'file:../images/svg/linked_accounts.svg' => 1,
    'file:../images/svg/membership.svg' => 1,
    'file:../images/svg/monetization.svg' => 1,
    'file:../images/svg/points.svg' => 1,
    'file:../images/svg/coinpayments.svg' => 1,
    'file:../images/svg/apps.svg' => 1,
    'file:../images/svg/user_information.svg' => 1,
    'file:../images/svg/pending.svg' => 1,
    'file:../images/svg/declined.svg' => 1,
    'file:../images/svg/accounts_switcher.svg' => 1,
    'file:../images/svg/admin_panel.svg' => 1,
    'file:../images/svg/logout.svg' => 1,
    'file:../images/svg/keyboard.svg' => 1,
    'file:../images/svg/themes_switcher.svg' => 1,
    'file:../images/svg/dark_light.svg' => 1,
    'file:../images/svg/watch.svg' => 1,
    'file:../images/svg/plus.svg' => 1,
    'file:../images/svg/sms.svg' => 1,
    'file:../images/svg/checkmark.svg' => 1,
    'file:../images/svg/pin.svg' => 1,
    'file:../images/svg/edit.svg' => 1,
    'file:../images/svg/hide.svg' => 1,
    'file:../images/svg/unhide.svg' => 1,
    'file:../images/svg/comments.svg' => 2,
    'file:../images/svg/link.svg' => 1,
    'file:../images/svg/block.svg' => 1,
    'file:../images/svg/report.svg' => 1,
    'file:../images/svg/pro.svg' => 1,
    'file:../images/svg/trend.svg' => 1,
    'file:../images/svg/payments.svg' => 1,
    'file:../images/svg/add.svg' => 1,
    'file:../images/svg/home.svg' => 1,
    'file:../images/svg/search.svg' => 1,
    'file:../images/svg/documents.svg' => 1,
    'file:../images/svg/checked.svg' => 1,
    'file:../images/svg/cross.svg' => 1,
    'file:../images/svg/permissions.svg' => 1,
    'file:../images/svg/links.svg' => 1,
    'file:../images/svg/media.svg' => 1,
    'file:../images/svg/verified_badge.svg' => 1,
    'file:../images/svg/pro_badge.svg' => 1,
    'file:../images/svg/genders.svg' => 1,
    'file:../images/svg/birthday.svg' => 1,
    'file:../images/svg/cog.svg' => 1,
    'file:../images/svg/tag.svg' => 1,
    'file:../images/svg/info.svg' => 1,
    'file:../images/svg/clock.svg' => 1,
    'file:../images/svg/going.svg' => 1,
    'file:../images/svg/crop.svg' => 1,
    'file:../images/svg/start_chat.svg' => 1,
    'file:../images/svg/close.svg' => 1,
    'file:../images/svg/upload.svg' => 1,
    'file:../images/svg/camera.svg' => 1,
    'file:../images/svg/login.svg' => 1,
    'file:../images/svg/fluid.svg' => 1,
    'file:../images/svg/fluid_vertical.svg' => 1,
    'file:../images/svg/vat.svg' => 1,
    'file:../images/svg/facebook.svg' => 1,
    'file:../images/svg/google.svg' => 1,
    'file:../images/svg/x.svg' => 1,
    'file:../images/svg/linkedin.svg' => 1,
    'file:../images/svg/vk.svg' => 1,
    'file:../images/svg/wordpress.svg' => 1,
    'file:../images/svg/youtube.svg' => 1,
    'file:../images/svg/instagram.svg' => 1,
    'file:../images/svg/twitch.svg' => 1,
    'file:../images/svg/whatsapp.svg' => 1,
    'file:../images/svg/reddit.svg' => 1,
    'file:../images/svg/pinterest.svg' => 1,
    'file:../images/svg/authorize.net.svg' => 1,
    'file:../images/svg/courses.svg' => 1,
    'file:../images/svg/yandex.svg' => 1,
    'file:../images/svg/merge.svg' => 1,
    'file:../images/svg/download.svg' => 1,
    'file:../images/svg/right_click.svg' => 1,
    'file:../images/svg/myfatoorah.svg' => 1,
    'file:../images/svg/flutterwave.svg' => 1,
    'file:../images/svg/mercadopago.svg' => 1,
    'file:../images/svg/reels.svg' => 1,
    'file:../images/svg/services.svg' => 1,
    'file:../images/svg/livekit.svg' => 1,
    'file:../images/svg/agora.svg' => 1,
    'file:../images/svg/cache-cleaner.svg' => 1,
    'file:../images/svg/pwa.svg' => 1,
    'file:../images/svg/pwa-install.svg' => 1,
    'file:../images/svg/media-player.svg' => 1,
    'file:../images/svg/merits.svg' => 1,
    'file:../images/svg/cronjob.svg' => 1,
    'file:../images/svg/swipe.svg' => 1,
    'file:../images/svg/schedule.svg' => 1,
    'file:../images/svg/heif.svg' => 1,
    'file:../images/svg/cloudflare.svg' => 1,
    'file:../images/svg/password.svg' => 1,
    'file:../images/svg/my-box.svg' => 1,
    'file:../images/svg/php.svg' => 1,
    'file:../images/svg/nodejs.svg' => 1,
    'file:../images/svg/socketio.svg' => 1,
    'file:../images/svg/ssl-sign.svg' => 1,
    'file:../images/svg/pushr.svg' => 1,
  ),
))) {
function content_68ed1f4fcd8c99_32375878 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/templates';
?><div class="svg-container <?php if ((true && ($_smarty_tpl->hasVariable('class') && null !== ($_smarty_tpl->getValue('class') ?? null)))) {
echo $_smarty_tpl->getValue('class');
}?>" style="<?php if ((true && ($_smarty_tpl->hasVariable('width') && null !== ($_smarty_tpl->getValue('width') ?? null)))) {?>width:<?php echo $_smarty_tpl->getValue('width');?>
;<?php }?> <?php if ((true && ($_smarty_tpl->hasVariable('height') && null !== ($_smarty_tpl->getValue('height') ?? null)))) {?>height:<?php echo $_smarty_tpl->getValue('height');?>
;<?php }?> <?php if ((true && ($_smarty_tpl->hasVariable('style') && null !== ($_smarty_tpl->getValue('style') ?? null)))) {
echo $_smarty_tpl->getValue('style');
}?>">

  <?php if ($_smarty_tpl->getValue('icon') == "2co") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/2co.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "paypal") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/paypal.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "alipay") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/alipay.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "bank") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/bank.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "bitcoin") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/bitcoin.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "photos") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/photos.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "videos") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/videos.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "audios") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/audios.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "files") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/files.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "sun") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/sun.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "night") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/night.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "afternoon") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/sunrise.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "scroll_desktop") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/scroll_desktop.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "scroll_mobile") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/scroll_mobile.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "chat") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/chat.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "settings") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/settings.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "24_hours") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/24_hours.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "trending") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/trending.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "memories") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/memories.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "language") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/language.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "posts_discover") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/posts_discover.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "popularity") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/popularity.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "posts_colored") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/posts_colored.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "posts_recent") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/posts_recent.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "social_share") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/social_share.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "youtube_player") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/youtube_player.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "adult") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/adult.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "watermark") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/watermark.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "jobs") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/jobs.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "google_recaptcha") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/google_recaptcha.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "censored") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/censored.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "fingerprint") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/fingerprint.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "firewall") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/firewall.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "chat_status") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/chat_status.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "chat_seen") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/chat_seen.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "chat_typing") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/chat_typing.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "call_video") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/call_video.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "call_audio") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/call_audio.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "aws_s3") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/aws_s3.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "digitalocean") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/digitalocean.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "server") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/server.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "twilio") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/twilio.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "infobip") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/infobip.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "bulksms") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/bulksms.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "msg91") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/msg91.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "email") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/email.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "authentication") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/authentication.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "ssl") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/ssl.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "smile") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/smile.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "map") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/map.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "polls") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/polls.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "gif") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/gif.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "wall_posts") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/wall_posts.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "verification") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/verification.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "age_limit") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/age_limit.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "getting_started") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/getting_started.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "account_activation") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/account_activation.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "newsletter") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/newsletter.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "delete_user") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/delete_user.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "registration") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/registration.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "invitation") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/invitation.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "invite_friend") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/invite_friend.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "wallet") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/wallet.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "resolution") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/resolution.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "website_live") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/website_live.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "website_public") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/website_public.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "directory") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/directory.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "contat_us") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/contat_us.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "adblock") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/adblock.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "cookie") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/cookie.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "browser_notifications") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/browser_notifications.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "noty_notifications") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/noty_notifications.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "profile_notifications") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/profile_notifications.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "gifts") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/gifts.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "poke") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/poke.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "onesignal") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/onesignal.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "like") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/like.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "comment") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/comment.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "share") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/share.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "developers") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/developers.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "affiliates") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/affiliates.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "withdrawal") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/withdrawal.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "wallet_transfer") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/wallet_transfer.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "pages") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/pages.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "groups") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/groups.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "events") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/events.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "market") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/market.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "products") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/products.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "forums") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/forums.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "ads") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/ads.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "movies") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/movies.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "games") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/games.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "find_people") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/find_people.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "saved") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/saved.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "blogs") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/blogs.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "boosted") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/boosted.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "newsfeed") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/newsfeed.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "share_plugin") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/share_plugin.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "followings") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/followings.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "friends") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/friends.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "followers") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/followers.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "cloud_save") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/cloud_save.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "database") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/database.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "star") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/star.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "profile") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/profile.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "chat_bell") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/chat_bell.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "notification_bell") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/notification_bell.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "user_online") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/user_online.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "spy") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/spy.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "stats") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/stats.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "voice_notes") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/voice_notes.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "offers") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/offers.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "live") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/live.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "delete") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/delete.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "empty") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/empty.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "ready") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/ready.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "relationship") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/relationship.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "website") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/website.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "biography") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/biography.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "education") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/education.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "username") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/username.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "design") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/design.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "funding") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/funding.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "money-bag") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/money-bag.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "transaction") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/transaction.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "paystack") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/paystack.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "header-menu") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/header-menu.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "header-home") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/header-home.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "header-plus") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/header-plus.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "header-friends") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/header-friends.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "header-messages") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/header-messages.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "header-notifications") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/header-notifications.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "header-search") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/header-search.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "playstore") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/playstore.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "playstore_badge") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/playstore_badge.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "appstore") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/appstore.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "appstore_badge") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/appstore_badge.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "appgallery") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/appgallery.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "appgallery_badge") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/appgallery_badge.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "wasabi") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/wasabi.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "google_cloud") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/google_cloud.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "html") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/html.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "razorpay") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/razorpay.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "cashfree") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/cashfree.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "coinbase") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/coinbase.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "shift4") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/shift4.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "stripe") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/stripe.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "special_characters") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/special_characters.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "backblaze") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/backblaze.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "ffmpeg") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/ffmpeg.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "reserved") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/reserved.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "views") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/views.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "locked") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/locked.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "noads") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/noads.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "moneypoolscash") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/moneypoolscash.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "tips") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/tips.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "tip") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/tip.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "edit_profile") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/edit_profile.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "security") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/security.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "notifications") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/notifications.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "privacy") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/privacy.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "blocking") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/blocking.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "user_add") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/user_add.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "linked_accounts") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/linked_accounts.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "membership") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/membership.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "monetization") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/monetization.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "points") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/points.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "coinpayments") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/coinpayments.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "apps") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/apps.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "user_information") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/user_information.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "delete_user") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/delete_user.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "pending") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/pending.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "declined") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/declined.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "accounts_switcher") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/accounts_switcher.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "admin_panel") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/admin_panel.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "logout") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/logout.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "keyboard") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/keyboard.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "themes_switcher") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/themes_switcher.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "dark_light") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/dark_light.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "watch") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/watch.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "plus") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/plus.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "sms") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/sms.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "checkmark") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/checkmark.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "pin") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/pin.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "edit") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/edit.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "hide") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/hide.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "unhide") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/unhide.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "comments") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/comments.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "link") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/link.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "block") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/block.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "report") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/report.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "pro") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/pro.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "trend") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/trend.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "payments") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/payments.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "add") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/add.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "home") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/home.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "comments") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/comments.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "search") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/search.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "documents") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/documents.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "checked") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/checked.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "cross") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/cross.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "permissions") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/permissions.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "links") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/links.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "media") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/media.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "verified_badge") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/verified_badge.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "pro_badge") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/pro_badge.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "genders") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/genders.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "birthday") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/birthday.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "cog") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/cog.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "tag") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/tag.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "info") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/info.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "clock") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/clock.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "going") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/going.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "crop") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/crop.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "start_chat") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/start_chat.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "close") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/close.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "upload") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/upload.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "camera") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/camera.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "login") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/login.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "fluid") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/fluid.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "fluid_vertical") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/fluid_vertical.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "vat") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/vat.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "facebook") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/facebook.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "google") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/google.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "x") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/x.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "linkedin") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/linkedin.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "vk") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/vk.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "wordpress") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/wordpress.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "youtube") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/youtube.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "instagram") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/instagram.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "twitch") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/twitch.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "whatsapp") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/whatsapp.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "reddit") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/reddit.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "pinterest") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/pinterest.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "authorize.net") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/authorize.net.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "courses") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/courses.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "yandex") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/yandex.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "merge") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/merge.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "download") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/download.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "right_click") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/right_click.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "myfatoorah") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/myfatoorah.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "flutterwave") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/flutterwave.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "mercadopago") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/mercadopago.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "reels") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/reels.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "services") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/services.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "livekit") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/livekit.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "agora") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/agora.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "cache-cleaner") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/cache-cleaner.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "pwa") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/pwa.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "pwa-install") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/pwa-install.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "media-player") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/media-player.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "merits") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/merits.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "cronjob") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/cronjob.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "swipe") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/swipe.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "schedule") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/schedule.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "heif") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/heif.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "cloudflare") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/cloudflare.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "password") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/password.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "my-box") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/my-box.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "php") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/php.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "nodejs") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/nodejs.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "socketio") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/socketio.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "ssl-sign") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/ssl-sign.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>

  <?php } elseif ($_smarty_tpl->getValue('icon') == "pushr") {?>

    <?php $_smarty_tpl->renderSubTemplate('file:../images/svg/pushr.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), (int) 0, $_smarty_current_dir);
?>
  <?php }?>

</div><?php }
}
