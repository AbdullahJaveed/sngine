<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:49:01
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/spy.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f6d1ad804_63259925',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9f4ae38c7fbf536b3821c37017e3fb933363107c' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/spy.svg',
      1 => 1760349425,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed1f6d1ad804_63259925 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 50 51" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g fill-rule="evenodd" clip-rule="evenodd"><path fill="#5e72e4" d="M27.096 37.61a4.688 4.688 0 0 0-4.192 0l-1.372.685a1.563 1.563 0 1 1-1.397-2.795l1.371-.686c2.2-1.1 4.788-1.1 6.988 0l1.372.686a1.563 1.563 0 0 1-1.398 2.795zM21.641 7.21h6.718c2.26 0 4.096 0 5.573.176 1.54.185 2.862.576 4.017 1.479 1.155.902 1.856 2.09 2.408 3.538.53 1.39.975 3.17 1.523 5.364l1.303 5.21a1.562 1.562 0 0 1-3.032.758l-1.279-5.115c-.577-2.31-.98-3.91-1.435-5.104-.44-1.156-.871-1.767-1.411-2.188-.54-.422-1.237-.692-2.465-.839-1.27-.151-2.918-.154-5.3-.154H21.74c-2.382 0-4.03.003-5.3.154-1.227.147-1.925.417-2.465.839-.54.421-.97 1.032-1.41 2.188-.456 1.195-.858 2.793-1.436 5.104l-1.279 5.115a1.562 1.562 0 0 1-3.031-.758l1.302-5.21c.548-2.193.993-3.974 1.523-5.364.552-1.449 1.253-2.636 2.408-3.538 1.156-.903 2.478-1.294 4.017-1.479 1.477-.176 3.313-.176 5.573-.176z" data-original="#999999"></path><g fill="#222"><path d="M36.458 31.169a5.73 5.73 0 1 0 0 11.458 5.73 5.73 0 0 0 0-11.458zm-8.854 5.73a8.854 8.854 0 1 1 17.708 0 8.854 8.854 0 0 1-17.708 0zM2.604 23.356c0-.863.7-1.562 1.563-1.562h41.666a1.563 1.563 0 0 1 0 3.125H4.167c-.863 0-1.563-.7-1.563-1.563zM13.542 31.169a5.73 5.73 0 1 0 0 11.458 5.73 5.73 0 0 0 0-11.458zm-8.854 5.73a8.854 8.854 0 1 1 17.708 0 8.854 8.854 0 0 1-17.709 0z" fill="#5e72e4" data-original="#222222" class=""></path></g></g></g></svg><?php }
}
