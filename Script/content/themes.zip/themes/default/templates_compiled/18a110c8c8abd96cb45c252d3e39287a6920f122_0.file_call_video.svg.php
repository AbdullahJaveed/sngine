<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:49:03
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/call_video.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f6fc08f10_72853384',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '18a110c8c8abd96cb45c252d3e39287a6920f122' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/call_video.svg',
      1 => 1760349432,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed1f6fc08f10_72853384 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path fill="#5e72e4" d="M19.51 18.07c-.38 0-.77-.09-1.12-.27l-2.83-1.42a.998.998 0 0 1 .9-1.78l2.83 1.42a.503.503 0 0 0 .73-.44V8.44a.503.503 0 0 0-.73-.45l-2.83 1.42a.998.998 0 0 1-.9-1.78l2.83-1.42c.78-.39 1.69-.35 2.43.11s1.19 1.26 1.19 2.13v7.14c0 .86-.46 1.68-1.19 2.13-.4.25-.86.37-1.31.37z" data-original="#ff38ac"></path><path fill="#5e72e4" d="M14.01 20H4.99c-1.65 0-3-1.35-3-3V7c0-1.65 1.35-3 3-3h9.02c1.65 0 3 1.35 3 3v10c0 1.65-1.35 3-3 3zM4.99 6c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h9.02c.55 0 1-.45 1-1V7c0-.55-.45-1-1-1z" data-original="#3c36b5" class=""></path></g></svg><?php }
}
