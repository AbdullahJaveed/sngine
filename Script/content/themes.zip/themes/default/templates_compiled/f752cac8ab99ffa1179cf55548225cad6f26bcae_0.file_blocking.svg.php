<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:49:03
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/blocking.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f6f805f02_01944885',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f752cac8ab99ffa1179cf55548225cad6f26bcae' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/blocking.svg',
      1 => 1760349432,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed1f6f805f02_01944885 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 32 32" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M15.501 2.002c-3.863 0-7 3.137-7 7 0 3.864 3.137 7 7 7s7-3.136 7-7c0-3.863-3.137-7-7-7zm0 2c2.76 0 5 2.241 5 5 0 2.76-2.24 5-5 5s-5-2.24-5-5c0-2.759 2.24-5 5-5zM3.501 28.002H16a1 1 0 0 1 0 2H2.501a1 1 0 0 1-1-1v-2a9 9 0 0 1 9-9H16a1 1 0 0 1 0 2h-5.499a7 7 0 0 0-7 7zM24.002 18.002c-3.587 0-6.499 2.912-6.499 6.499S20.415 31 24.002 31s6.499-2.912 6.499-6.499-2.912-6.499-6.499-6.499zm0 2c2.483 0 4.499 2.016 4.499 4.499S26.485 29 24.002 29s-4.499-2.016-4.499-4.499 2.016-4.499 4.499-4.499z" fill="#5e72e4" data-original="#000000" class=""></path><path d="m27.177 19.901-7.775 7.775a1 1 0 0 0 1.414 1.414l7.775-7.775a.999.999 0 1 0-1.414-1.414z" fill="#5e72e4" data-original="#000000" class=""></path></g></svg><?php }
}
