<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:49:02
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/media.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f6ea51666_44891820',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6431f02f5086dcc31ffcefc594368d902489db38' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/media.svg',
      1 => 1760349430,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed1f6ea51666_44891820 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 32 32" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g data-name="Layer 21"><path d="m15.51 11.14-5-3A1 1 0 0 0 9 9v6a1 1 0 0 0 .51.87A1 1 0 0 0 10 16a1 1 0 0 0 .51-.14l5-3a1 1 0 0 0 0-1.72ZM11 13.23v-2.46L13.06 12Z" fill="#5e72e4" data-original="#000000" class=""></path><path d="M22 16V8a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v8a4 4 0 0 0 4 4v3a1 1 0 0 0 .62.92A.84.84 0 0 0 7 24a1 1 0 0 0 .71-.29l3.7-3.71H18a4 4 0 0 0 4-4Zm-11 2a1 1 0 0 0-.71.29L8 20.59V19a1 1 0 0 0-1-1H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2Z" fill="#5e72e4" data-original="#000000" class=""></path><path d="M26 8h-1a1 1 0 0 0 0 2h1a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-1a1 1 0 0 0-1 1v1.59l-2.29-2.3A1 1 0 0 0 21 22h-7a1.93 1.93 0 0 1-1-.29 1 1 0 1 0-1.06 1.7A3.93 3.93 0 0 0 14 24h6.59l3.7 3.71A1 1 0 0 0 25 28a.84.84 0 0 0 .38-.08A1 1 0 0 0 26 27v-3a4 4 0 0 0 4-4v-8a4 4 0 0 0-4-4Z" fill="#5e72e4" data-original="#000000" class=""></path></g></g></svg><?php }
}
