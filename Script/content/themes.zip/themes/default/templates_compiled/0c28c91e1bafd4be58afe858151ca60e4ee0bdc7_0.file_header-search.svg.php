<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:48:53
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/header-search.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f65a55fc5_82846230',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0c28c91e1bafd4be58afe858151ca60e4ee0bdc7' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/header-search.svg',
      1 => 1760349430,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed1f65a55fc5_82846230 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
?><svg height="512" viewBox="0 0 24 24" width="512" xmlns="http://www.w3.org/2000/svg"><g id="_12" data-name="12"><path d="m21.71 20.29-2.83-2.82a9.52 9.52 0 1 0 -1.41 1.41l2.82 2.83a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42zm-17.71-8.79a7.5 7.5 0 1 1 7.5 7.5 7.5 7.5 0 0 1 -7.5-7.5z"/></g></svg><?php }
}
