<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:48:53
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/pages.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f65f292b5_15879464',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f7544ea5a3d5623bee0e41e9cc49865dcd0e28b4' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/pages.svg',
      1 => 1760349429,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed1f65f292b5_15879464 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
?><svg id="Layer_1" enable-background="new 0 0 32 32" height="512" viewBox="0 0 32 32" width="512" xmlns="http://www.w3.org/2000/svg"><path d="m26.9 18.6-2.1-5.2 2.1-5.1c.2-.5 0-1.1-.5-1.3-.1 0-.3 0-.4 0h-9v-2c0-.6-.4-1-1-1h-9v-1c0-.6-.4-1-1-1s-1 .4-1 1v26c0 .6.4 1 1 1s1-.4 1-1v-12h6c0 1.7 1.3 3 3 3h10c.6 0 1-.5 1-1 0-.1 0-.3-.1-.4zm-19.9-3.6v-9h8v9zm9 3c-.6 0-1-.4-1-1h1c.6 0 1-.4 1-1v-7h7.5l-1.7 4.1c-.1.2-.1.5 0 .8l1.7 4.2h-8.5z"/></svg><?php }
}
