<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:49:03
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/sun.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f6fdee172_26896710',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6bd9abf61121172c553b3c4c394480e02e215c02' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/sun.svg',
      1 => 1760349431,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed1f6fdee172_26896710 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 504 504" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M423.194 297.872C433.896 257.933 493 252 493 252s-59.104-5.933-69.806-45.872S459.847 132 459.847 132s-53.287 23.914-82.524-5.323S372 44.153 372 44.153s-34.19 47.354-74.128 36.652S252 11 252 11s-5.933 59.104-45.872 69.806S132 44.153 132 44.153s23.914 53.287-5.323 82.524S44.153 132 44.153 132s47.354 34.19 36.652 74.128S11 252 11 252s59.104 5.933 69.806 45.872S44.153 372 44.153 372s53.287-23.914 82.524 5.323S132 459.845 132 459.845s34.19-47.354 74.128-36.652S252 493 252 493s5.933-59.106 45.872-69.807S372 459.845 372 459.845s-23.914-53.285 5.323-82.522S459.847 372 459.847 372s-47.354-34.19-36.653-74.128z" style="stroke-width:22;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:10;" fill="none" stroke="#33cccc" stroke-width="22" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" data-original="#33cccc" class=""></path><circle cx="252" cy="252" r="120" style="stroke-width:22;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:10;" fill="none" stroke="#5e72e4" stroke-width="22" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" data-original="#000000"></circle><path d="M432 72h0M72 72h0M72 432h0M432 432h0" style="stroke-width:22;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:10;" fill="none" stroke="#5e72e4" stroke-width="22" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" data-original="#000000"></path></g></svg><?php }
}
