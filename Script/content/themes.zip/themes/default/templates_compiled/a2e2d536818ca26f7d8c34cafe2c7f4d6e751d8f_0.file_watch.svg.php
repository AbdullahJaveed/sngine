<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:48:58
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/watch.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f6a3d7269_43129004',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a2e2d536818ca26f7d8c34cafe2c7f4d6e751d8f' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/watch.svg',
      1 => 1760349428,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed1f6a3d7269_43129004 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g data-name="Layer 2"><g fill="#232323"><path d="M19 18h-1.5a1 1 0 0 1 0-2H19a2.003 2.003 0 0 0 2-2V5a2.003 2.003 0 0 0-2-2H5a2.003 2.003 0 0 0-2 2v9a2.003 2.003 0 0 0 2 2h9a1 1 0 0 1 0 2H5a4.004 4.004 0 0 1-4-4V5a4.004 4.004 0 0 1 4-4h14a4.004 4.004 0 0 1 4 4v9a4.004 4.004 0 0 1-4 4zM7 22H2a1 1 0 0 1 0-2h5a1 1 0 0 1 0 2zM22 22H10a1 1 0 0 1 0-2h12a1 1 0 0 1 0 2z" fill="#5e72e4" data-original="#232323" class=""></path></g><path fill="#7fbde7" d="M10.23 13.502a1.892 1.892 0 0 1-1.885-1.889V7.387a1.887 1.887 0 0 1 2.731-1.688l4.226 2.114a1.885 1.885 0 0 1-.001 3.375L11.076 13.3a1.895 1.895 0 0 1-.846.201zm.115-5.933v3.862l3.86-1.931z" data-original="#7fbde7" class=""></path><path fill="#5e72e4" d="M7 23.5a1 1 0 0 1-1-1v-3a1 1 0 0 1 2 0v3a1 1 0 0 1-1 1z" data-original="#232323" class=""></path></g></g></svg><?php }
}
