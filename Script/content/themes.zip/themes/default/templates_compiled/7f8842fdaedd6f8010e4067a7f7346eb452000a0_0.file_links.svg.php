<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:49:02
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/links.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f6e96dca3_70283209',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7f8842fdaedd6f8010e4067a7f7346eb452000a0' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/links.svg',
      1 => 1760349431,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed1f6e96dca3_70283209 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="m8.464 14.121 5.657-5.657a1 1 0 1 1 1.414 1.414l-5.656 5.657a1 1 0 0 1-1.415-1.414zm4.243.414a1 1 0 0 0-1 1A2.4 2.4 0 0 1 11 17.243l-1.828 1.828a3 3 0 0 1-4.244-4.243L6.756 13a2.4 2.4 0 0 1 1.708-.707 1 1 0 0 0 0-2 4.387 4.387 0 0 0-3.122 1.293l-1.828 1.828a5 5 0 0 0 7.072 7.071l1.828-1.828a4.386 4.386 0 0 0 1.293-3.122 1 1 0 0 0-1-1zm.707-11.02-1.828 1.828a4.384 4.384 0 0 0-1.293 3.121 1 1 0 0 0 2 0A2.397 2.397 0 0 1 13 6.757l1.828-1.828a3 3 0 0 1 4.243 4.243L17.243 11a2.398 2.398 0 0 1-1.708.707 1 1 0 1 0 0 2 4.387 4.387 0 0 0 3.122-1.293l1.828-1.828a5 5 0 0 0-7.071-7.071z" fill="#5e72e4" data-original="#000000"></path></g></svg><?php }
}
