<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:48:55
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/keyboard.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f67bc2d71_52852022',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2380b748999e03f917d623bd2a4e28d384ed6f97' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/keyboard.svg',
      1 => 1760349426,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed1f67bc2d71_52852022 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g data-name="Layer 2"><path fill="#5e72e4" d="M12 21c-4.08 0-7.45-1-9-2.6C.34 15.65.34 8.35 3 5.6 4.55 4 7.92 3 12 3s7.45 1 9 2.6c2.65 2.75 2.65 10.05 0 12.8-1.55 1.6-4.92 2.6-9 2.6zm0-16c-3.39 0-6.43.8-7.57 2-1.89 2-1.89 8.07 0 10 1.14 1.2 4.18 2 7.57 2s6.43-.8 7.57-2c1.89-2 1.89-8.07 0-10-1.14-1.2-4.18-2-7.57-2z" data-original="#232323" class=""></path><path fill="#7fbde7" d="M16 17H8a1 1 0 0 1 0-2h8a1 1 0 0 1 0 2z" data-original="#7fbde7" class=""></path><g fill="#232323"><circle cx="18" cy="9" r="1" fill="#5e72e4" data-original="#232323" class=""></circle><circle cx="14" cy="9" r="1" fill="#5e72e4" data-original="#232323" class=""></circle><circle cx="10" cy="9" r="1" fill="#5e72e4" data-original="#232323" class=""></circle><circle cx="6" cy="9" r="1" fill="#5e72e4" data-original="#232323" class=""></circle><circle cx="18" cy="12.5" r="1" fill="#5e72e4" data-original="#232323" class=""></circle><circle cx="14" cy="12.5" r="1" fill="#5e72e4" data-original="#232323" class=""></circle><circle cx="10" cy="12.5" r="1" fill="#5e72e4" data-original="#232323" class=""></circle><circle cx="6" cy="12.5" r="1" fill="#5e72e4" data-original="#232323" class=""></circle></g></g></g></svg><?php }
}
