<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:49:00
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/photos.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f6c2b24e6_30834254',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '31678c526ac817aeb2c309d93b43762e019c4448' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/photos.svg',
      1 => 1760349430,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed1f6c2b24e6_30834254 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 32 32" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><circle cx="8.813" cy="13.079" r="1.813" fill="#5e72e4" data-original="#f98a17"></circle><path fill="#5e72e4" d="M26.72 2.1H9.55a3.184 3.184 0 0 0-3.18 3.181v1.086H5.283A3.186 3.186 0 0 0 2.1 9.55v17.167a3.188 3.188 0 0 0 3.183 3.184H22.45a3.188 3.188 0 0 0 3.183-3.184v-1.086h1.087a3.184 3.184 0 0 0 3.18-3.181V5.28a3.183 3.183 0 0 0-3.18-3.18zM5.283 8.167H22.45c.763 0 1.383.62 1.383 1.383v11.917l-4.731-5.446a2.375 2.375 0 0 0-3.584-.001l-3.689 4.241-.986-1.133a2.372 2.372 0 0 0-3.583 0L3.9 22.986V9.55c0-.763.621-1.383 1.383-1.383zM3.9 26.717v-.99l4.716-5.417c.149-.172.336-.197.434-.197s.285.025.435.197l6.779 7.79H5.283A1.385 1.385 0 0 1 3.9 26.717zM22.45 28.1h-3.8l-5.628-6.467 3.854-4.431c.15-.172.336-.197.435-.197s.285.025.435.197l6.089 7.009v2.507A1.387 1.387 0 0 1 22.45 28.1zm5.65-5.65c0 .761-.619 1.38-1.38 1.38h-1.087V9.55a3.188 3.188 0 0 0-3.183-3.184H8.17V5.28c0-.761.619-1.38 1.38-1.38h17.17c.761 0 1.38.619 1.38 1.38z" data-original="#6621ba" class=""></path></g></svg><?php }
}
