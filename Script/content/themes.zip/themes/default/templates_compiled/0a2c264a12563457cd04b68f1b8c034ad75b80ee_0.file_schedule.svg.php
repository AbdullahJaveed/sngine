<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:48:57
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/schedule.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f69d49ad7_69395195',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0a2c264a12563457cd04b68f1b8c034ad75b80ee' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/schedule.svg',
      1 => 1760349432,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed1f69d49ad7_69395195 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M279 364c0 22.056 17.944 40 40 40h47c22.056 0 40-17.944 40-40v-47c0-22.056-17.944-40-40-40h-47c-22.056 0-40 17.944-40 40v47zm40-47h47l.025 46.999L366 364h-47v-47z" fill="#5e72e4" data-original="#000000" class=""></path><circle cx="386" cy="210" r="20" fill="#5e72e4" data-original="#000000" class=""></circle><circle cx="299" cy="210" r="20" fill="#5e72e4" data-original="#000000" class=""></circle><path d="M492 352c11.046 0 20-8.954 20-20V120c0-44.112-35.888-80-80-80h-26V20c0-11.046-8.954-20-20-20s-20 8.954-20 20v20h-91V20c0-11.046-8.954-20-20-20s-20 8.954-20 20v20h-90V20c0-11.046-8.954-20-20-20s-20 8.954-20 20v20H80C35.888 40 0 75.888 0 120v312c0 44.112 35.888 80 80 80h352c44.112 0 80-35.888 80-80 0-11.046-8.954-20-20-20s-20 8.954-20 20c0 22.056-17.944 40-40 40H80c-22.056 0-40-17.944-40-40V120c0-22.056 17.944-40 40-40h25v20c0 11.046 8.954 20 20 20s20-8.954 20-20V80h90v20c0 11.046 8.954 20 20 20s20-8.954 20-20V80h91v20c0 11.046 8.954 20 20 20s20-8.954 20-20V80h26c22.056 0 40 17.944 40 40v212c0 11.046 8.954 20 20 20z" fill="#5e72e4" data-original="#000000" class=""></path><circle cx="125" cy="384" r="20" fill="#5e72e4" data-original="#000000" class=""></circle><circle cx="125" cy="210" r="20" fill="#5e72e4" data-original="#000000" class=""></circle><circle cx="125" cy="297" r="20" fill="#5e72e4" data-original="#000000" class=""></circle><circle cx="212" cy="297" r="20" fill="#5e72e4" data-original="#000000" class=""></circle><circle cx="212" cy="210" r="20" fill="#5e72e4" data-original="#000000" class=""></circle><circle cx="212" cy="384" r="20" fill="#5e72e4" data-original="#000000" class=""></circle></g></svg><?php }
}
