<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:48:55
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/accounts_switcher.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f677e1245_96383546',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '289928d8a9e53f373311252d381a4b7f9ce188c8' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/accounts_switcher.svg',
      1 => 1760349429,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed1f677e1245_96383546 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="m21.816 13.773-1.931-2.728a1 1 0 0 0-1.395-.239l-2.727 1.931a1 1 0 1 0 1.156 1.632l.913-.646a6.037 6.037 0 0 1-.914 1.867A6.039 6.039 0 0 1 12 18.09c-1.78 0-3.46-.774-4.605-2.126a1 1 0 0 0-1.525 1.294A8.02 8.02 0 0 0 12 20.09c2.568 0 5.01-1.24 6.531-3.318a8.027 8.027 0 0 0 1.212-2.466l.44.622a1 1 0 1 0 1.633-1.156zM8.476 9.87a1 1 0 0 0-1.395-.24l-.913.647A6.031 6.031 0 0 1 7.08 8.41 6.041 6.041 0 0 1 12 5.91c1.781 0 3.46.775 4.606 2.126a1 1 0 0 0 1.525-1.294A8.021 8.021 0 0 0 12 3.91a8.127 8.127 0 0 0-6.532 3.318 8.024 8.024 0 0 0-1.211 2.467l-.44-.623a1 1 0 1 0-1.633 1.155l1.93 2.728a1 1 0 0 0 1.395.24l2.728-1.932a1 1 0 0 0 .239-1.394z" fill="#5e72e4" data-original="#000000" class=""></path></g></svg><?php }
}
