<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:48:57
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/posts_discover.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f698a0bc6_49446990',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e3a540decd1dfe4f141f6630b4ea22084501c28a' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/posts_discover.svg',
      1 => 1760349433,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed1f698a0bc6_49446990 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g data-name="1"><path d="M12 22.745a10.745 10.745 0 1 1 7.6-3.145 10.721 10.721 0 0 1-7.6 3.145zm0-19.991a9.246 9.246 0 1 0 6.541 2.7A9.224 9.224 0 0 0 12 2.754zM8 17" fill="#5e72e4" data-original="#000000" class=""></path><path fill="#3d7df8" d="M16.772 7.227a.974.974 0 0 0-1.025-.216L9.628 9.172l-.013.009a.737.737 0 0 0-.261.164l-.012.012a.75.75 0 0 0-.163.259l-.008.013-2.161 6.117a.978.978 0 0 0 .219 1.028.945.945 0 0 0 .675.276 1.05 1.05 0 0 0 .351-.061l6.115-2.16.013-.008a.74.74 0 0 0 .261-.165l.012-.012a.741.741 0 0 0 .163-.259l.008-.013 2.162-6.119a.975.975 0 0 0-.217-1.026zm-7.981 7.982 1.4-3.958 2.56 2.56zm5.018-2.459-2.559-2.56 3.958-1.4z" data-original="#3d7df8" class=""></path></g></g></svg><?php }
}
