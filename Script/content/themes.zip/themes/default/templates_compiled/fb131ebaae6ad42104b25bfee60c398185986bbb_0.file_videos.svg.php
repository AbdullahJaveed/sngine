<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:49:00
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/videos.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f6ce5ff48_07921834',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fb131ebaae6ad42104b25bfee60c398185986bbb' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/videos.svg',
      1 => 1760349432,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed1f6ce5ff48_07921834 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g data-name="Layer 2"><path fill="#5e72e4" d="M12 21c-3.17 0-6.34-.69-7.8-2.08S2 15 2 12s.82-5.62 2.2-6.93c2.91-2.78 12.69-2.78 15.6 0C21.18 6.38 22 9 22 12s-.82 5.62-2.2 6.93C18.34 20.32 15.17 21 12 21zm0-16c-2.69 0-5.37.5-6.42 1.5S4 9.58 4 12s.62 4.57 1.58 5.48c2.1 2 10.74 2 12.84 0 1-.91 1.58-3.06 1.58-5.48s-.62-4.57-1.58-5.48S14.69 5 12 5z" data-original="#232323"></path><path fill="#7fbde7" d="M10.69 15.35A1.71 1.71 0 0 1 9 13.65v-3.3a1.7 1.7 0 0 1 2.45-1.52l3.3 1.66a1.68 1.68 0 0 1 0 3l-3.3 1.66a1.7 1.7 0 0 1-.76.2zm.31-4.51v2.32L13.31 12z" data-original="#7fbde7"></path></g></g></svg><?php }
}
