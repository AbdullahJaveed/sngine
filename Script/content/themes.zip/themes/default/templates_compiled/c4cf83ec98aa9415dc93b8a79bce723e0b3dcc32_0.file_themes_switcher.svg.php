<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:48:36
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/themes_switcher.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f54714df2_77649666',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c4cf83ec98aa9415dc93b8a79bce723e0b3dcc32' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/themes_switcher.svg',
      1 => 1760349428,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed1f54714df2_77649666 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g fill="#ff38ac"><path d="M18.1 14.58H5.9c-.5 0-.93-.38-.99-.88L3.83 5.12c-.11-.85.16-1.71.73-2.36s1.39-1.02 2.25-1.02h10.38c.86 0 1.68.37 2.25 1.02s.83 1.51.73 2.36l-1.08 8.58c-.06.5-.49.88-.99.88zm-11.31-2h10.43l.97-7.71a.99.99 0 0 0-.24-.79c-.19-.21-.46-.34-.75-.34H6.81c-.29 0-.56.12-.75.34s-.28.5-.24.79z" fill="#5e72e4" data-original="#ff38ac"></path><path d="M15 6.75c-.55 0-1-.45-1-1V3.29c0-.55.45-1 1-1s1 .45 1 1v2.46c0 .55-.45 1-1 1zM12 6.04c-.55 0-1-.45-1-1V3.3c0-.55.45-1 1-1s1 .45 1 1v1.74c0 .55-.45 1-1 1zM9 6.75c-.55 0-1-.45-1-1V3.29c0-.55.45-1 1-1s1 .45 1 1v2.46c0 .55-.45 1-1 1z" fill="#5e72e4" data-original="#ff38ac"></path></g><path fill="#5e72e4" d="M17.61 17.75H6.39c-1.42 0-2.58-1.16-2.58-2.58s1.16-2.58 2.58-2.58h11.22c1.42 0 2.58 1.16 2.58 2.58s-1.16 2.58-2.58 2.58zM6.39 14.58a.58.58 0 0 0 0 1.16h11.22a.58.58 0 0 0 0-1.16z" data-original="#3c36b5" class=""></path><path fill="#5e72e4" d="M12 22.25c-.8 0-1.56-.31-2.12-.88S9 20.05 9 19.25v-2.5c0-.55.45-1 1-1h4c.55 0 1 .45 1 1v2.5c0 1.65-1.35 3-3 3zm-1-4.5v1.5a.99.99 0 0 0 1 1c.55 0 1-.45 1-1v-1.5z" data-original="#3c36b5" class=""></path></g></svg><?php }
}
