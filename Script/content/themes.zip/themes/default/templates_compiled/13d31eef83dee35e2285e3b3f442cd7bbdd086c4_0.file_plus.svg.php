<?php
/* Smarty version 5.5.2, created on 2025-10-13 15:49:00
  from 'file:/var/www/html/Script/content/themes/default/templates/../images/svg/plus.svg' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.5.2',
  'unifunc' => 'content_68ed1f6c698117_70346100',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '13d31eef83dee35e2285e3b3f442cd7bbdd086c4' => 
    array (
      0 => '/var/www/html/Script/content/themes/default/templates/../images/svg/plus.svg',
      1 => 1760349428,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_68ed1f6c698117_70346100 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = '/var/www/html/Script/content/themes/default/images/svg';
?><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="512" height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M156 256c0 11.046 8.954 20 20 20h60v60c0 11.046 8.954 20 20 20s20-8.954 20-20v-60h60c11.046 0 20-8.954 20-20s-8.954-20-20-20h-60v-60c0-11.046-8.954-20-20-20s-20 8.954-20 20v60h-60c-11.046 0-20 8.954-20 20zM160.406 61.8l25.869-10.716c10.204-4.228 15.051-15.927 10.823-26.132-4.228-10.205-15.926-15.054-26.132-10.823l-25.869 10.716c-10.204 4.228-15.051 15.927-10.823 26.132 4.214 10.171 15.894 15.061 26.132 10.823z" fill="#5e72e4" data-original="#000000"></path><path d="M256 0c-11.046 0-20 8.954-20 20s8.954 20 20 20c119.378 0 216 96.608 216 216 0 119.378-96.608 216-216 216-119.378 0-216-96.608-216-216 0-11.046-8.954-20-20-20s-20 8.954-20 20c0 141.483 114.497 256 256 256 141.483 0 256-114.497 256-256C512 114.517 397.503 0 256 0zM93.366 113.165l19.799-19.799c7.811-7.811 7.811-20.475 0-28.285-7.811-7.81-20.475-7.811-28.285 0L65.081 84.88c-7.811 7.811-7.811 20.475 0 28.285 7.809 7.809 20.474 7.811 28.285 0zM24.952 197.099c10.227 4.236 21.914-.642 26.132-10.823l10.716-25.87c4.228-10.205-.619-21.904-10.823-26.132-10.207-4.227-21.904.619-26.132 10.823l-10.716 25.869c-4.228 10.206.619 21.905 10.823 26.133z" fill="#5e72e4" data-original="#000000"></path></g></svg><?php }
}
